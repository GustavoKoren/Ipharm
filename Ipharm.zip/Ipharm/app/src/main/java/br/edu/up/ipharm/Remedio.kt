package br.edu.up.ipharm

data class Remedio(
    val nome: String,
    val foto: String,
    val msg : String,
    val comprar: String
)
