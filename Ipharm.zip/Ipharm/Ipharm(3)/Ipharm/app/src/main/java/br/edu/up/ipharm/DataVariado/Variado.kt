package br.edu.up.ipharm.DataVariado

data class Variado(
    val nomeVariado: String,
    val fotoVariado: String,
    val msgVariado : String
)
