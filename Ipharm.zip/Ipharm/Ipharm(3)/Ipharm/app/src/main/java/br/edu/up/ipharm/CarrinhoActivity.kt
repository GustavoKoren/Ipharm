package br.edu.up.ipharm

import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import br.edu.up.ipharm.DataRemedio.RemedioViewModel
import br.edu.up.ipharm.DataRemedio.RemediosAdapter

class CarrinhoActivity : AppCompatActivity() {

    private lateinit var recyclerCarrinho: RecyclerView
    private val remedioViewModel: RemedioViewModel by viewModels()
    private lateinit var carrinhoAdapter: RemediosAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_carrinho)

        recyclerCarrinho = findViewById(R.id.recyclerCarrinho)

        // Configurar o adapter com o layout e ações
        carrinhoAdapter = RemediosAdapter(emptyList(),
            onImageClick = { remedio ->
                Toast.makeText(this, "${remedio.nome} selecionado!", Toast.LENGTH_SHORT).show()
            },
            onDeleteClick = { remedio ->
                remedioViewModel.deleteRemedio(remedio)
                Toast.makeText(this, "${remedio.nome} removido do carrinho!", Toast.LENGTH_SHORT).show()
            }
        )

        recyclerCarrinho.adapter = carrinhoAdapter
        recyclerCarrinho.layoutManager = LinearLayoutManager(this)

        // Observar a lista de remédios
        remedioViewModel.readAllData.observe(this) { remedios ->
            carrinhoAdapter.lista = remedios
            carrinhoAdapter.notifyDataSetChanged()
        }
    }
}
