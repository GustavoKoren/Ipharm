package br.edu.up.ipharm

data class Variado(
    val nomeVariado: String,
    val fotoVariado: String,
    val msgVariado : String
)
